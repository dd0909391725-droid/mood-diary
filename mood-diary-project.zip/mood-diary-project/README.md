# Mood Diary｜每一種心情，都值得被記錄

一個以繁體中文呈現的個人心情日記網站。採用 HTML、CSS 與原生 JavaScript 製作，不需要安裝套件或資料庫。

## 功能
- 每日選擇六種心情之一，撰寫日記並設定 1～5 級心情強度
- 同一天再次儲存會更新當天紀錄
- 日記回顧、日期篩選、編輯與刪除
- 月曆檢視及每日紀錄查詢
- 心情統計：紀錄天數、最常見心情、平均強度與分布
- 暱稱設定、JSON 備份匯出、清除全部日記
- 內建完整「使用說明」頁面

## 本機預覽
直接以瀏覽器開啟 `index.html` 即可使用。

## GitHub Pages / Cloudflare Pages 部署
1. 將 `index.html` 與 `README.md` 上傳到 GitHub repository 根目錄。
2. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git。
3. 選擇此 GitHub repository。
4. Framework preset 選 `None`；Build command 留空；Build output directory 填 `/`（若介面要求輸出資料夾，選 repository 根目錄）。
5. 部署完成後，Cloudflare 會提供 `*.pages.dev` 網址。

## 資料與隱私
日記與暱稱使用瀏覽器 `localStorage` 儲存，只存在目前裝置與瀏覽器，不會上傳至伺服器，也不會自動跨裝置同步。清除瀏覽器資料可能造成紀錄遺失，請定期使用 JSON 匯出功能備份。請勿在共用裝置記錄敏感資訊。

## 專案檔案
- `index.html`：完整網站及使用說明
- `README.md`：專案介紹與部署指引
